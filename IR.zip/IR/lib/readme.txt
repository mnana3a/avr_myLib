Remote Control Interafacing Library for Atmel AVR series of MCUs.
Please see
http://www.eXtremeElectronics.co.in

for more info.
