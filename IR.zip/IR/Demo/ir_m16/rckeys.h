#ifndef _RCKEYS_H
 #define _RCKEYS_H

/*____________________________________________________________________________________*/

//KeyCodes
//*********

#define RC_UP 		11

#define RC_DOWN 	27

#define RC_LEFT 	90

#define RC_RIGHT 	24

#define RC_ENTER 	88 

#define RC_VOL_INC 	16

#define RC_VOL_DEC	19

/*____________________________________________________________________________________*/

#endif
